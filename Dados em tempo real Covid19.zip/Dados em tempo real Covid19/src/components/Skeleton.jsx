import Skeleton from '@material-ui/lab/Skeleton'

export default Skeleton